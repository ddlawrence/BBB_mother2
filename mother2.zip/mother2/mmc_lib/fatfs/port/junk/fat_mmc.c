//
//  FAT32 - MMC  top-level interface
//
//  this file was originally from elm-chan
//  it was modded by TI dude for bbb mmc I/O
//  it contains the h/w dependant mmc driver interface
//  the functions herein are called by the 
//  elm-chan FAT32 filesystem routines in ff.c
//  the functions herein call the mmc_api routines
//
#include "diskio.h"
#include "hw_types.h"
#include "mmc_api.h"
#include "ff.h"

extern unsigned int year, month, day, hour, min, sec;

#define DEBUG                 1  // ddl

typedef struct _fatDevice
{
    /* Pointer to underlying device/controller */
    void *dev;
    
    /* File system pointer */
    FATFS *fs;

	/* state */
	unsigned int initDone;

}fatDevice;


#define DRIVE_NUM_MMCSD     0
#define DRIVE_NUM_MAX      2

fatDevice fat_devices[DRIVE_NUM_MAX];

/*-----------------------------------------------------------------------*/
/* Initialize Disk Drive                                                 */
/*-----------------------------------------------------------------------*/

DSTATUS
disk_initialize(
    BYTE bValue)                /* Physical drive number (0) */
{
	unsigned int status;

    if (DRIVE_NUM_MAX <= bValue)
    {
        return STA_NODISK;
    }
    
    if ((DRIVE_NUM_MMCSD == bValue) && (fat_devices[bValue].initDone != 1))
    {
        mmcsdCardInfo *card = (mmcsdCardInfo *) fat_devices[bValue].dev;
        
        /* SD Card init */
        status = MMCSDCardInit(card->ctrl);
        if (status == 0)
        {
            ConsolePrintf("\r\nCard Init Failed \r\n");
            return STA_NOINIT;
        } else {
#if DEBUG
            if (card->cardType == MMCSD_CARD_SD) {
                ConsolePrintf("\nSD Card version %d", card->sd_ver);
                if (card->highCap) {
                    ConsolePrintf(" high capacity");
                }
                if (card->tranSpeed == SD_TRANSPEED_50MBPS) {
                    ConsolePrintf(" high speed");
                }
                ConsolePrintf("\n\n"); // ddl
            } else {
              if (card->cardType == MMCSD_CARD_MMC) ConsolePrintf("\nMMC Card\n", -1);
            }
#endif            
            /* Set bus width */
            if (card->cardType == MMCSD_CARD_SD)
            {
                MMCSDBusWidthSet(card->ctrl);
            }
    
            /* Transfer speed */
            MMCSDTranSpeedSet(card->ctrl);
         }
         fat_devices[bValue].initDone = 1;
    }
    return 0;
}

/*-----------------------------------------------------------------------*/
/* Returns the current status of a drive                                 */
/*-----------------------------------------------------------------------*/

DSTATUS disk_status (
    BYTE drv)                   /* Physical drive number (0) */
{
	return 0;
}

/*-----------------------------------------------------------------------*/
/* This function reads sector(s) from the disk drive                     */
/*-----------------------------------------------------------------------*/

DRESULT disk_read (
    BYTE drv,               /* Physical drive number (0) */
    BYTE* buff,             /* Pointer to the data buffer to store read data */
    DWORD sector,           /* Physical drive number (0) */
    BYTE count)             /* Sector count (1..255) */
{
	if (drv == DRIVE_NUM_MMCSD)
	{
		mmcsdCardInfo *card = fat_devices[drv].dev;

gpio_on(SOC_GPIO_1_REGS, 0x4<<21);  // ddl  flash LED USR3

    	/* READ BLOCK */
		if (MMCSDReadCmdSend(card->ctrl, buff, sector, count) == 1) {

gpio_off(SOC_GPIO_1_REGS, 0x4<<21);  // ddl  flash LED USR3

      return RES_OK;
		}
  }
  return RES_ERROR;
}


/*-----------------------------------------------------------------------*/
/* This function writes sector(s) to the disk drive                     */
/*-----------------------------------------------------------------------*/

#if _READONLY == 0
DRESULT disk_write (
    BYTE ucDrive,           /* Physical drive number (0) */
    const BYTE* buff,      /* Pointer to the data to be written */
    DWORD sector,          /* Start sector number (LBA) */
    BYTE count)            /* Sector count (1..255) */
{
	if (ucDrive == DRIVE_NUM_MMCSD)	{
		mmcsdCardInfo *card = fat_devices[ucDrive].dev;

gpio_on(SOC_GPIO_1_REGS, 0x8<<21);  // ddl  flash LED USR4

tim_delay(1);  // ddl  delay required for large files (1G file copy takes half an hour!)
               //      this is the only major change needed in all the mmc driver s/w
               //      FR_RW_ERROR 0x8 
               //      the problem may go away when running 1GHz - TODO

    /* WRITE BLOCK */
	  if(MMCSDWriteCmdSend(card->ctrl,(BYTE*) buff, sector, count) == 1) {

gpio_off(SOC_GPIO_1_REGS, 0x8<<21);  // ddl  flash LED USR4

      return RES_OK;
		}
  }
  return RES_ERROR;
}
#endif /* _READONLY */

/*-----------------------------------------------------------------------*/
/* Miscellaneous Functions                                               */
/*-----------------------------------------------------------------------*/

DRESULT disk_ioctl (
    BYTE drv,               /* Physical drive number (0) */
    BYTE ctrl,              /* Control code */
    void *buff)             /* Buffer to send/receive control data */
{
	return RES_OK;
}

/*---------------------------------------------------------*/
/* User Provided Timer Function for FatFs module           */
/*---------------------------------------------------------*/
/* This is a real time clock service to be called from     */
/* FatFs module. Any valid time must be returned even if   */
/* the system does not support a real time clock.          */

DWORD get_fattime (void)
{
    return ((((year >> 4) & 0x7) * 10 + (year & 0xF)) << 25)  // year 0 = 1980
         | ((((month >> 4) & 0x1) * 10 + (month & 0xF)) << 21)
         | ((((day >> 4) & 0x3) * 10 + (day & 0xF)) << 16)
         | ((((hour >> 4) & 0x3) * 10 + (hour & 0xF)) << 11)
         | ((((min >> 4) & 0x7) * 10 + (min & 0xF)) << 5)
         | ((((sec >> 4) & 0x7) * 10 + (sec & 0xF)) >> 1);  // 5 bits ie 2 sec resolution
}
